import Vue from 'vue'
import VueI18n from 'vue-i18n'

Vue.use(VueI18n)

export const i18n = new VueI18n({
locale: 'ua',
ua: {
    pages: {
      users: 'Користувачі',
      goods: 'Товари',
      demands: 'Замовлення',
      payments: 'Платежі',
      turnovers: 'Товарообіг',
      signin: 'Увійти',
      signout: 'Вийти',
      about: 'Про програму ...',
    }
  },
en: {
    pages: {
      users: 'Users',
      goods: 'Goods',
      demands: 'Demands',
      payments: 'Payments',
      turnovers: 'Turnovers',
      signin: 'Sign in',
      signout: 'Sign out',
      about: 'About ...',
    }
  },
ru: {
    pages: {
      users: 'Пользователи',
      goods: 'Товары',
      demands: 'Заказы',
      payments: 'Платежи',
      turnovers: 'Товарооборот',
      signin: 'Войти',
      signout: 'Выйти',
      about: 'О программе ...',
    }
  }

})