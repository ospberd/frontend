<template>
<!-- App.vue -->

<v-app>
  <v-navigation-drawer v-model="drawer" temporary app>
    <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="text-h6">
              Магазинчик
            </v-list-item-title>
            <v-list-item-subtitle>
              м.Бердичів "Продукти"
            </v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
<v-list nav dense >
          <v-list-item v-for="item in items" :key="item.title" router :to="item.link" >
            <v-list-item-icon>
              <v-icon>{{ item.icon }}</v-icon>
            </v-list-item-icon>
  
            <v-list-item-content >
              <v-list-item-title>{{ item.title }}</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
          <v-list-item>
              <v-list-item-content >
                  <v-switch small v-model="$vuetify.theme.dark"></v-switch>Темна тема
              </v-list-item-content>
          </v-list-item>
          <v-list-item>
              <v-list-item-content >
                <div>
                        <v-btn outlined>UA</v-btn>
                        <v-btn outlined>EN</v-btn>
                        <v-btn outlined>RU</v-btn>
                </div>
                
              </v-list-item-content>
          </v-list-item>


        </v-list>
 
  </v-navigation-drawer>

  <v-app-bar app>
    <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
    <!-- -->
  </v-app-bar>

  <!-- Sizes your content based upon application components -->
  <v-main>

    <!-- Provides the application the proper gutter -->
    <v-container >

      <!-- If using vue-router -->
      <router-view></router-view>
    </v-container>
  </v-main>

  <v-footer app>
            
    <p> 2021  Oliynyk S.P. +380679761971</p>
  </v-footer>
</v-app>
</template>

<script>

export default {
  name: 'App',

  data: () => ({
    drawer: false,
    group: null,
    items: [
        { title: 'Замовлення', icon: 'mdi-file-document-edit',link: '/' },
        { title: 'Накладні', icon: 'mdi-text-box-check',link: '/' },
        { title: 'Товари', icon: 'mdi-food-variant',link: '/goods' },
        { title: 'Користувачі', icon: 'mdi-account-group',link: '/' },
        { title: 'Увійти', icon: 'mdi-login',link: '/loginpage' },
        { title: 'Вийти', icon: 'mdi-logout',link: '/' },
        { title: 'Про це ...', icon: 'mdi-information-variant',link: '/about' },
      ],

  }),
    watch: {
    group () {
      this.drawer = false
    },
  },
};
</script>
