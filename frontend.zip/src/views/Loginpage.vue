<template>
  <div>
 
<v-card elevation="12" class="mx-auto"  max-width="600"  > 
  <v-banner color="primary" dark elevation="4">Вхід до системи </v-banner>
  <v-row>
    <v-col class="ma-4"  >
        <v-text-field label="Логін" placeholder="Ваш логін" outlined v-model="login" ></v-text-field>
        <v-text-field label="Пароль" placeholder="Ваш пароль" outlined v-model="password"></v-text-field> 
      
        <v-col class="d-flex justify-space-between" >
            <v-btn> Забув пароль </v-btn>
            <v-btn color="primary" @click.stop="signIn" > Увійти </v-btn>
        </v-col>
    </v-col>
  </v-row>


</v-card>

  </div>
</template>


<script>
export default {
  name: 'Loginpage',

  computed: {   },
  methods: { 
  async signIn() {

      const res = await fetch('http://localhost:3000/api/users/login', {
          method: 'POST', mode: 'cors', headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ login: this.login, password: this.password  })      
       })

     const token = await res.json();
     console.log(token);
     localStorage.setItem('user', JSON.stringify(token))
    }
    

     },
   
  data: () => ({

    login: "",
    password: "",
  })

   
}
</script>